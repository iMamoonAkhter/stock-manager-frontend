const orders = [
  {
    id: 1,
    name: "Ahsan",
    number: "03134162172",
    products: 3,
    price: 1200,
    status: "paid",
  },
];
export default orders;
