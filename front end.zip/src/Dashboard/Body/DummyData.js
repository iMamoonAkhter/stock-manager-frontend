const userdata = [
  {
    name: "Jan",
    sales: 4000,
    expense: 2400,
    revanue: 2400,
  },
  {
    name: "Feb",
    sales: 5000,
    expense: 3400,
    revanue: 4400,
  },
  {
    name: "Mar",
    sales: 3000,
    expense: 1400,
    revanue: 3400,
  },
  {
    name: "Apr",
    sales: 5000,
    expense: 6400,
    revanue: 4400,
  },
  {
    name: "May",
    sales: 3400,
    expense: 2100,
    revanue: 2700,
  },
  {
    name: "Jun",
    sales: 6000,
    expense: 1400,
    revanue: 1400,
  },
  {
    name: "Jul",
    sales: 2000,
    expense: 1400,
    revanue: 3300,
  },
  {
    name: "Aug",
    sales: 7000,
    expense: 3300,
    revanue: 5500,
  },
  {
    name: "Spet",
    sales: 4400,
    expense: 1400,
    revanue: 1300,
  },
  {
    name: "Oct",
    sales: 4000,
    expense: 2400,
    revanue: 2400,
  },
  {
    name: "Nov",
    sales: 4900,
    expense: 8800,
    revanue: 1900,
  },
  {
    name: "Dec",
    sales: 4000,
    expense: 2400,
    revanue: 8400,
  },
];
export default userdata;
