const menu = [
  {
    id: 1,
    title: "laptop",
    category: "laptop",
    price: 15.99,
    img: "../pics/l1.png",
    desc: `I'm baby woke mlkshk wolf bitters live-edge blue bottle, hammock freegan copper mug whatever cold-pressed `,
  },
  {
    id: 2,
    title: "mobile",
    category: "mobile",
    price: 13.99,
    img: "../pics/m1.jpg",
    desc: `vaporware iPhone mumblecore selvage raw denim slow-carb leggings gochujang helvetica man braid jianbing. Marfa thundercats `,
  },
  {
    id: 3,
    title: "tv",
    category: "tv",
    price: 6.99,
    img: "../pics/t1.jpg",
    desc: `ombucha chillwave fanny pack 3 wolf moon street art photo booth before they sold out organic viral.`,
  },

  {
    id: 4,
    title: "tv",
    category: "tv",
    price: 6.99,
    img: "../pics/t1.jpg",
    desc: `ombucha chillwave fanny pack 3 wolf moon street art photo booth before they sold out organic viral.`,
  },
  {
    id: 5,
    title: "tv",
    category: "tv",
    price: 6.99,
    img: "../pics/t1.jpg",
    desc: `ombucha chillwave fanny pack 3 wolf moon street art photo booth before they sold out organic viral.`,
  },
  {
    id: 6,
    title: "tv",
    category: "tv",
    price: 6.99,
    img: "../pics/t1.jpg",
    desc: `ombucha chillwave fanny pack 3 wolf moon street art photo booth before they sold out organic viral.`,
  },
  {
    id: 7,
    title: "tv",
    category: "tv",
    price: 6.99,
    img: "../pics/t1.jpg",
    desc: `ombucha chillwave fanny pack 3 wolf moon street art photo booth before they sold out organic viral.`,
  },
  {
    id: 8,
    title: "tv",
    category: "tv",
    price: 6.99,
    img: "../pics/t1.jpg",
    desc: `ombucha chillwave fanny pack 3 wolf moon street art photo booth before they sold out organic viral.`,
  },
];
// import axios from "axios";
// const items = async () => {
//   axios
//     .get("http://localhost:3007/API/products")
//     .then((res) => {
//       console.log(res.data);

//       // history.push("/login");
//     })
//     .catch((err) => {
//       console.log(err);
//     });
// };
// export default { items } ;

export default menu;
